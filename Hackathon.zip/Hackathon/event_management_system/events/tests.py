# from django.test import TestCase
#
# # Create your tests here.
# from django.test import TestCase
# from django.contrib.auth.models import User
# from .models import Event
#
# class EventTestCase(TestCase):
#     def setUp(self):
#         self.user = User.objects.create(username="testuser")
#         self.event = Event.objects.create(
#             name="Test Event",
#             description="Test description",
#             location="Test location",
#             start_time="2024-09-15 10:00:00",
#             end_time="2024-09-15 12:00:00"
