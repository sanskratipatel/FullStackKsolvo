from django import forms
from .models import Event
from django.forms.widgets import DateTimeInput


class EventForm(forms.ModelForm):
    start_time = forms.DateTimeField(
        widget=DateTimeInput(attrs={'type': 'datetime-local'}),
        input_formats=['%Y-%m-%dT%H:%M']
    )
    end_time = forms.DateTimeField(
        widget=DateTimeInput(attrs={'type': 'datetime-local'}),
        input_formats=['%Y-%m-%dT%H:%M']
    )

    class Meta:
        model = Event
        fields = ['name', 'description', 'location', 'start_time', 'end_time']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
