from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponseForbidden
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import Event, Attendee, Notification, ActivityLog
from .forms import EventForm
from .utils import send_event_reminder


@login_required
def create_event(request):
    if request.method == "POST":
        form = EventForm(request.POST)
        if form.is_valid():
            event = form.save(commit=False)
            event.organizer = request.user
            event.save()
            messages.success(request, "Event created successfully.")
            # Log the activity
            log_user_activity(request.user, f"Created event '{event.name}'")
            return redirect('event_detail', event_id=event.id)
    else:
        form = EventForm()
    return render(request, 'events/create_event.html', {'form': form})


@login_required
def list_events(request):
    events = Event.objects.all().order_by('-created_at')
    return render(request, 'events/event_list.html', {'events': events})


@login_required
def event_detail(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    attendees = Attendee.objects.filter(event=event)
    notifications = Notification.objects.filter(user=request.user, is_read=False)
    return render(request, 'events/event_detail.html', {
        'event': event,
        'attendees': attendees,
        'notifications': notifications
    })


@login_required
def delete_event(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if event.organizer == request.user:
        event.delete()
        messages.success(request, "Event deleted successfully.")
        # Log the activity
        log_user_activity(request.user, f"Deleted event '{event.name}'")
        return redirect('list_events')
    else:
        return HttpResponseForbidden("You are not authorized to delete this event.")


@login_required
def rsvp(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    attendee, created = Attendee.objects.get_or_create(event=event, user=request.user)
    if not attendee.rsvp_status:
        attendee.rsvp_status = True
        attendee.rsvp_at = timezone.now()
        attendee.save()
        messages.success(request, f"RSVP'd to event '{event.name}'.")
        # Log the activity
        log_user_activity(request.user, f"RSVP'd to event '{event.name}'")
    else:
        messages.info(request, f"You have already RSVPed to '{event.name}'.")
    return redirect('event_detail', event_id=event.id)


@login_required
def send_reminder(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if event.organizer != request.user:
        return HttpResponseForbidden("You are not authorized to send reminders for this event.")

    attendees = Attendee.objects.filter(event=event, rsvp_status=True)
    for attendee in attendees:
        # Send email reminder
        send_mail(
            subject=f"Reminder: {event.name}",
            message=f"Hi {attendee.user.username},\n\nThis is a reminder for the event '{event.name}' scheduled on {event.start_time} at {event.location}.\n\nDescription: {event.description}\n\nBest Regards,\nEvent Management Team",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[attendee.user.email],
            fail_silently=False,
        )
        # Create in-app notification
        Notification.objects.create(
            user=attendee.user,
            event=event,
            message=f"Reminder: '{event.name}' is scheduled on {event.start_time} at {event.location}."
        )
    messages.success(request, "Reminders sent to all attendees.")
    # Log the activity
    log_user_activity(request.user, f"Sent reminders for event '{event.name}'")
    return redirect('event_detail', event_id=event.id)


@login_required
def view_notifications(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    # Mark all as read
    notifications.update(is_read=True)
    return render(request, 'events/notifications.html', {'notifications': notifications})


def log_user_activity(user, action):
    ActivityLog.objects.create(user=user, action=action)
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Log the activity
            log_user_activity(user, "Signed up")
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            messages.success(request, "Signup successful. You are now logged in.")
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})
