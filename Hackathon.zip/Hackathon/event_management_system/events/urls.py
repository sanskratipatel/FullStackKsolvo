from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_event, name='create_event'),
    path('list/', views.list_events, name='list_events'),
    path('detail/<int:event_id>/', views.event_detail, name='event_detail'),
    path('delete/<int:event_id>/', views.delete_event, name='delete_event'),
    path('rsvp/<int:event_id>/', views.rsvp, name='rsvp'),
    path('send_reminder/<int:event_id>/', views.send_reminder, name='send_reminder'),
]
